# Clare Scout County — County Events Calendar (v0_2)

A single-page county calendar for all six sections, with a PIN-gated admin for
adding events. Events are stored in Netlify Blobs, so one person adds an event
and everyone sees it.

Themed on the county badge: deep blue #1F409B, sun yellow #FFF100, sky blue
#00B9F0, grass green #8DC345, dolmen brown #51432C and stone grey #B5A8A3. The
badge itself is embedded in `public/index.html` as a base64 PNG, so there is no
separate image file to lose.

## Deploy (zip drop)

1. Go to https://app.netlify.com/drop
2. Drag this whole zip file onto the page (do not unzip it first).
3. Wait for the deploy to finish, then open the site URL.

The zip contains:

```
netlify.toml                  site config
public/index.html             the whole front end
netlify/functions/events.mjs  the events API (pre-bundled, no build step)
```

## Admin PIN

The default PIN is **1907**.

To change it: Netlify dashboard → Site configuration → Environment variables →
add `ADMIN_PIN` with your chosen value, then Deploys → Trigger deploy →
Clear cache and deploy site.

The PIN is an entry barrier, not security. Anyone who knows it can edit the
calendar, and the events themselves are public.

## Using it

- **Section pills** filter the whole calendar to one section. "All Sections"
  shows everything.
- **Type toggles** switch each colour on and off. The three types take their
  colours from the badge: **Training** = sky blue, **County** = sun yellow,
  **National** = grass green. Colour coding is consistent across calendar,
  table and detail views.
- **Calendar / Table** switches views. On phones the calendar becomes a
  month-by-month agenda automatically.
- **Export .ics** downloads whatever is currently filtered, so a Cub Scouter can
  filter to Cubs and import just those events into their own calendar. Individual
  events have an "Add to my calendar" button.

## Admin

Click **Admin**, enter the PIN, then add, edit or delete events. Nothing is live
until you press **Publish to the calendar**. "Discard changes" throws away
unpublished edits.

**Export JSON** downloads the full event list as a backup. **Import JSON** loads
one back in (still needs Publish). Worth taking an export before a big edit.

## Event fields

| Field | Notes |
|---|---|
| Event name | required |
| Start date | required |
| End date | optional, for camps and weekends |
| Type | Training, County or National |
| Sections | one or more, or All Sections |
| Time | free text, e.g. `10:00 – 16:00` |
| Location / venue | free text |
| Description | free text |
| Hosted by | group or team running it |
| Contact name / email / phone | all optional |

## Notes

- Netlify Blobs is enabled automatically on Netlify sites. If publishing ever
  returns "Could not save", check the function log under Netlify → Logs →
  Functions.
- The site is one HTML file plus one function. To change the look, edit
  `public/index.html` and re-drop the zip.
